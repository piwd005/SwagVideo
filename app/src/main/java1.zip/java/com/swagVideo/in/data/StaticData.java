package com.swagVideo.in.data;

public class StaticData {

    public static String latitude="";
    public static String longitude="";
    public static String placeName="";

}
