package com.swagVideo.in.data.models;

import java.util.Date;

public class ArticleSection {

    public int id;
    public String name;
    public Date createdAt;
    public Date updatedAt;
    public int articlesCount;
}
