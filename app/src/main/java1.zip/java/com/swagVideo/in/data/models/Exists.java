package com.swagVideo.in.data.models;

public class Exists {

    public boolean exists;
}
