package com.swagVideo.in.data.models;

import java.util.Date;

public class Hashtag {

    public int id;
    public String name;
    public int clips;
    public Date createdAt;
    public Date updatedAt;
}
